const mysql = require('mysql2');

// Create a connection to the database
const connection = mysql.createConnection({
  host: 'mysql-182908-0.cloudclusters.net', 
  port: '10039',    // Replace with your MySQL host
  user: 'admin',          // Replace with your MySQL username
  password: 'Bhawi@11',  // Replace with your MySQL password
  database: 'playflix'     // Replace with your database name
});


// Connect to the MySQL server
connection.connect(err => {
  if (err) {
    console.error('Error connecting to the MySQL database:', err.stack);
    return;
  }
  console.log('Connected to the MySQL database as id ' + connection.threadId);
});
