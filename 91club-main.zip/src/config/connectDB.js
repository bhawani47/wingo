const mysql = require('mysql2/promise');
const dotenv = require('dotenv');
dotenv.config();
const connection = mysql.createPool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    password:process.env.DB_PASSWORD,
    database: process.env.DB_NAME
});

// const connection = mysql.createConnection({
//     host: 'mysql-182908-0.cloudclusters.net', 
//     port: '10039',    // Replace with your MySQL host
//     user: 'admin',          // Replace with your MySQL username
//     password: 'Bhawi@11',  // Replace with your MySQL password
//     database: 'playflix'     // Replace with your database name
//   });

// const connection = mysql.createPool({
//     host: 'localhost',
//     user: 'admin',
//     password: 'Dph51mO5qkS8U1k',
//     database: '92lottery'
// });

export default connection;